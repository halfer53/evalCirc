#include <unistd.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/times.h>
#include <float.h>
#include <sys/types.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

const int N = 1000;
const int M = 1000;



void randmatrix(double (*matrix)[N]){
  const double div = RAND_MAX;
  srand(times(NULL));
  for (size_t i = 0; i < N; i++) {
    for (size_t j = 0; j < N; j++) {
      matrix[i][j] = (double)rand() / RAND_MAX;
    }
  }
}


void test1(double (*C)[N], double (*A)[N], double (*B)[N]){
  for (size_t i = 0; i < N; i++) {
    //read matrix[0:N]
    for (size_t j = 0; j < N; j++) {
      //read matrix[][0:N]
      for (size_t k = 0; k < M; k++) {
        
        C[i][j] = A[i][k] * B[k][j];
      }
    }
  }
}

void test2(double (*C)[N], double (*A)[N], double (*B)[N]){
  for (size_t i = 0; i < N; i++) {
    for (size_t j = 0; j < N; j++) {
      for (size_t k = 0; k < M; k++) {
        // *get_matrix(C,i,j) = *get_matrix(A,i,k) * *get_matrix(B,i,k);
        C[i][j] = A[i][k] * B[k][j];
      }
    }
  }
}

unsigned long long getTime(){
  struct timeval t;
  unsigned long long sec, msec, nsec;

  while (gettimeofday(&t, NULL) != 0);
  sec = t.tv_sec;
  msec = t.tv_usec;

  nsec = sec * 1000000000 + msec * 1000;

  return nsec;
}




int main(int argc, char const *argv[]) {

  double (*A)[N] = malloc(sizeof(double[N][N]));
  double (*B)[N] = malloc(sizeof(double[N][N]));
  double (*C)[N] = malloc(sizeof(double[N][N]));
  unsigned long long t1, t2;

  randmatrix(A);
  randmatrix(B);
  randmatrix(C);
  double sum = 0.0;

  t1 = getTime();
  // test1(C,A,B);

  t2 = getTime();

  printf("time %6.6f\n", (t2 - t1) / 1000000000.0);

  for (size_t i = 0; i < N; i++ ) {
    for (size_t j = 0; j < N; j++) {
      sum += C[i][j];
    }
  }
  printf("sum %10.10f\n", sum);
  return 0;
}

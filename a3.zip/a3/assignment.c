/* do not add other includes */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/times.h>
#include <assert.h>
#include <time.h>
#include <float.h>

unsigned long long getTime(){
  struct timeval t;
  unsigned long long sec, msec, nsec;

  while (gettimeofday(&t, NULL) != 0);
  sec = t.tv_sec;
  msec = t.tv_usec;

  nsec = sec * 1000000000 + msec * 1000;

  return nsec;
}

/* for task 1 only */
void usage(void)
{
	fprintf(stderr, "Usage: cachetest1/2 [--repetitions M] [--array_size N]\n");
	exit(1);
}

inline void randomB(int *b, int N){
  srand(times(NULL));
  for (size_t i = 0; i < N; i++) {
    int r1 = rand() % N;
    int r2 = rand() % N;
    int tmp = b[r1];
    b[r1] = b[r2];
    b[r2] = tmp;
  }
}

inline void initialise_b(int* b, int N){
  for (size_t i = 0; i < N; i++) {
    b[i] = i;
  }
}

inline void initialise_a(int *a, int N){
  for (size_t i = 0; i < N; i++) {
    a[i] = N+ i;
  }
}

inline int do_testing(int* a, int *b, int N, int M){
  int sum = 0;
  for (size_t i = 0; i < M; i++) {
    for (size_t j = 0; j < N; j++) {
      sum += a[b[j]];
    }
  }
  return sum;
}


inline void getNandM(int* N, int* M, int argc, char* argv[]){
  /* parameter parsing task 1 */
  int i;
  for(i=1; i<(unsigned)argc; i++) {
	  if (strcmp(argv[i], "--repetitions") == 0) {
		  i++;
		  if (i < argc)
			  sscanf(argv[i], "%u", M);
		  else
			  usage();
	  } else if (strcmp(argv[i], "--array_size") == 0) {
		  i++;
		  if (i < argc)
			  sscanf(argv[i], "%u", N);
		  else
			  usage();
	  } else usage();
  }
}

int main (int argc, char *argv[])
{
  unsigned long long t1, t2, t3,t4;
  int sum, sum2;

  /* variables for task 1 */
  unsigned int M = 1000;
  unsigned int N = 256*1024;

  /* declare variables; examples, adjust for task */
	//int *a;
	int *a, *b;
  getNandM(&N, &M, argc, argv);


  /* allocate memory for arrays; examples, adjust for task */
	 //a = malloc (N * sizeof(int));

	 /* initialise arrray elements */
   a = malloc(N * sizeof(int));
   b = malloc(N * sizeof(int));
   initialise_a(a, N);
   initialise_b(b, N);

  t1 = getTime();
  sum = do_testing(a, b, N, M);
  t2 = getTime();

  randomB(b,N);

  t3 = getTime();
  sum2 = do_testing(a, b, N, M);
	t4 = getTime();

  assert(sum == sum2);
  /* output; examples, adjust for task */

  double iterations = (double)(N*M);
  unsigned long long v1 = t2 - t1;
  unsigned long long v2 = t4 - t3;
  printf("%d\t%6.8f\t%6.8f\n",N,(double)v1/iterations, (double)v2/iterations);

  /* free memory; examples, adjust for task */
  free(a);
  free(b);

  return 0;
}
